const names = ["Arslan", "Zeeshan", "Husnain"]

const sortedNames = names.sort();

for(const name of sortedNames){
    console.log(name)
}
