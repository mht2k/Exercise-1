const favoriteTransports = ["Honda car", "Yaris car", "Suzuki car"];

for(const transport of favoriteTransports){
   console.log("I would like to own a " + transport + ".")
}
