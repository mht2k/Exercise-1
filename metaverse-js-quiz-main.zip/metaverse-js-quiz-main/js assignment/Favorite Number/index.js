const favoriteNum = 13;
const message = `My favorite Number is: ${favoriteNum}`;
console.log(message)