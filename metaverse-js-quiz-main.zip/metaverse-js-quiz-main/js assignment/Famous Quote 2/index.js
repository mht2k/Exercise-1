const famous_person = "Albert Einstein";
const fmQuote = `"A person who never made a mistake never tried anything new."`;
const message = `${famous_person} once said, ${fmQuote}`;
console.log(message)