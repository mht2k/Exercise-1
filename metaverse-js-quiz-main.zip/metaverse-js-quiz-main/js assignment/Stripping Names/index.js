const person = " \t M Adeel Chaudhary \n ";
console.log(person)
console.log(person.trim())
